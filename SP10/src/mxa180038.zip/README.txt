 /**
 * @authors Manindra Kumar Anantaneni,  Venkata Naga Sai Rohith Reddy Isukapalli
 */

Prerequisites:
IntelliJ IDEA
Java(JDK) 8

This project is about implementation  of Strongly Connected Components using Depth First Search (DFS).

Implementations of Depth First Search:

Files included :
DFS.java
Graph.java
 
DFS.java consists of methods for Strongly Connected Components, toplogical Order, and Depth First Search

Graph.java is a given file