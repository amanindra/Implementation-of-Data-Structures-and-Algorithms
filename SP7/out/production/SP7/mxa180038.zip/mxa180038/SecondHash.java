package mxa180038;

public interface SecondHash<K>{
    int hashCode2(K key);
}