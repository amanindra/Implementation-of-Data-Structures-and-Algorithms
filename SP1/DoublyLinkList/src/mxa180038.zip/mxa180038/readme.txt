After executing the Program, the program displays the elements present in the List.

You can traverse the list forward, or backward using the numbers 1 & 2 respectively.
To add new elements while traversing, you can do so using by using the number 3.
And to remove elements from the list use the number 4.

Thanks

Manindra Kumar Anantaneni
Shiva Prasad Reddy