Team Members:
Manindra Kumar Anantaneni : mxa180038	
Vineet Vats - vxv180008

Prerequisites:
Eclipse Java Oxygen
Java(JDK) 8

Create a java project and create  java file in it.Copy the codes in a file named as BinaryHeap.java.

Inputs and procedure to run the program:
Firstly we have to input the maximum size of the Binary Heap as it is a bounded-size Binary Heap.
Then, we have to input the queue size in which we can add that number of element in one go.
Now there are 5 options - 1, 2, 3,4,5.
Entering 1 will ask for an element to the binary heap and will send that value to its appropriate location.
Entering 2 adds an element to the binary heap and return false if pq is full.
Entering 3 removes the root element in the binary heap and it return  emptythrow exception if pq is empty.
Entering 4 removes the first element in the binary heap and it return false if pq is empty.
Entering 5 returns the first element in the priority queue having highest priority and return null if pq is empty
Entering 6 will display all the elements present in the queue (not necessarily in the order of their priority though), the way they are arranged in the queue at that time of execution 
Project Completed.